package com.makers.princemaker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrinceMakerApplicationTests {

	@Test
	void contextLoads() {
	}

}
