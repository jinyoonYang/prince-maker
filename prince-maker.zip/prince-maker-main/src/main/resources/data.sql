insert into prince (age, prince_level, skill_type, experience_years, prince_id,
                    name, created_at, updated_at)
VALUES (41, 'KING', 'WARRIOR', 14, 'snow.y', 'snow', now(), now());

insert into prince (age, prince_level, skill_type, experience_years, prince_id, name, created_at, updated_at)
VALUES (36, 'JUNIOR_PRINCE', 'INTELLECTUAL', 2, 'sunny.flower', 'john', now(), now());
