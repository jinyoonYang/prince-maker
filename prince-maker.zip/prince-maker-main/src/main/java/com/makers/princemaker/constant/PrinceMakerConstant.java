package com.makers.princemaker.constant;

/**
 * @author Snow
 */
public class PrinceMakerConstant {
    public static final Integer MIN_KING_EXPERIENCE_YEARS = 10;
    public static final Integer MAX_JUNIOR_EXPERIENCE_YEARS = 5;
}
